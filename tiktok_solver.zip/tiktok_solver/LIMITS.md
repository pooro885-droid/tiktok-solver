# LIMITS

Honest assessment of what this solver can and cannot do.

## Selector rot

TikTok rotates CSS class names and DOM structure as frequently as every
few weeks. The selectors in `detect.py` and `extract.py` will eventually
miss. When the solver returns `UNKNOWN` on a page that visually shows a
captcha, the selectors are stale — open DevTools, find the new class
pattern, update the `_*_SELS` lists in `detect.py` and `extract.py`.

## Rotate CV fallback accuracy

The sweep + NCC approach in `rotatesolve.py` achieves roughly ±3° under
clean conditions. TikTok's rotate tolerance has been observed as low as
0–2°, which means the CV fallback will fail a meaningful fraction of
attempts. A trained CNN regression model (e.g. a ResNet-18 fine-tuned on
rotate captcha pairs) typically reaches ±0.5–1°. The `RotateSolver.score()`
hook is the insertion point. Drop `rotate_model.onnx` in the project root
and install `onnxruntime` — the solver loads it automatically.

## Stealth arms race

`playwright-stealth` patches the most probed navigator properties. TikTok's
bot detection layer also checks:
- Mouse movement entropy (addressed by the eased drag path in `drag.py`)
- TLS fingerprint (use real Chromium, not custom builds)
- Canvas and WebGL fingerprint (not patched here)
- Cookie and session state

Running headless sharply increases detection rate. `--headless` exists for
CI but is not recommended for production solve workloads.

## Iframe origin changes

If TikTok serves the captcha from a cross-origin iframe, `page.evaluate`
calls inside that frame will throw security errors. The solver handles
same-origin iframes only. Cross-origin iframe extraction requires
intercepting network responses (Playwright route API) to rewrite CORS
headers — not implemented here.

## Rate limiting and lockout

After 3–5 failed attempts in quick succession TikTok imposes a timed
lockout (observed: 30s–5min). The backoff in `solver.py` addresses this
but cannot prevent a lockout from triggering. If the solver is run at
high volume from a single IP, the account or IP will be flagged regardless
of solve accuracy.

## What this does not do

- No account creation, no session management, no login automation.
- No bypass of 2FA or SMS verification.
- No support for TikTok's newer "puzzle piece" variant (distinct from slider).
- No mobile/app captcha support — web only.
- No paid API fallback path.
