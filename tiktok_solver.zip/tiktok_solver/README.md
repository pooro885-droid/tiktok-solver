# tiktok_solver

Local TikTok captcha solver + comment bot.  
Cookie auth (Netscape or JSON) · search + scroll + comment loop · auto captcha solve · rate-limit detection.  
No paid APIs. No external captcha services.

---

## Codespaces / VPS quickstart

```bash
# 1. Install
pip install -r requirements.txt
playwright install chromium

# 2. Put your cookies on GitHub (or any raw URL)
#    Export cookies from browser with a cookie-editor extension → save as cookies.txt
#    Push to a private repo, copy the raw URL

# 3. Run
python run.py \
  --cookie-source "https://raw.githubusercontent.com/YOU/REPO/main/cookies.txt" \
  --search "steal an egg script" \
  --comment 'loadstring(game:HttpGet("https://raw.githubusercontent.com/pooro885-droid/stealanegg/refs/heads/main/saemain.lua"))()' \
  --count 50
```

---

## Cookie formats

Both are supported, auto-detected:

**Netscape (most cookie exporters)**
```
# Netscape HTTP Cookie File
.tiktok.com	TRUE	/	TRUE	1999999999	sessionid	abc123...
.tiktok.com	TRUE	/	FALSE	0	tt_webid	xyz...
```

**JSON array (EditThisCookie, Cookie-Editor)**
```json
[
  {"name": "sessionid", "value": "abc123", "domain": ".tiktok.com", "path": "/", ...},
  ...
]
```

**JSON flat dict**
```json
{"sessionid": "abc123", "tt_webid": "xyz", ...}
```

---

## All options

| Flag | Env var | Default | Description |
|------|---------|---------|-------------|
| `--cookie-source` | `COOKIE_SOURCE` | required | Raw URL or local path to cookie file |
| `--search` | `SEARCH_QUERY` | required | TikTok search query |
| `--comment` | `COMMENT_TEXT` | required | Comment text to post |
| `--count` | `TARGET_COUNT` | 50 | Number of videos to comment on |
| `--headless` | `HEADLESS=1` | false | Run headless (not recommended) |
| `--delay-min` | `DELAY_MIN` | 8.0 | Min seconds between comments |
| `--delay-max` | `DELAY_MAX` | 18.0 | Max seconds between comments |
| `--no-debug` | — | false | Disable debug image dumps |
| `--output` | — | results.json | JSON results output path |

---

## How it works

1. **Cookie load** — fetches cookie file from raw URL or local path at boot. Supports Netscape and JSON.
2. **Inject** — injects into Playwright context before first navigation. No login form touched.
3. **Verify** — navigates to tiktok.com, checks for logged-in DOM signals. Aborts if cookies are expired.
4. **Search** — navigates to `/search/video?q=<query>`, switches to Videos tab.
5. **Collect URLs** — scrolls feed, harvests `/video/` hrefs up to target count.
6. **Comment loop** — for each URL:
   - Navigate to video
   - Check for captcha → solve automatically if present
   - Click comment box, type with human-like keystroke delays
   - Submit (button or Enter)
   - Detect outcome: success / rate-limit / captcha / error
   - Rate-limited → exponential backoff (60–180s base, doubles on repeat)
   - Captcha after submit → solver fires, re-submits
7. **Results** — writes `results.json` with per-video success/fail/status.

---

## Rate-limit behaviour

The `AdaptiveRateLimiter` tracks outcomes:
- After a rate-limit signal: delay floor jumps to 60–180s, doubles on repeat hits
- After 5 consecutive successes: delay creeps back toward base (8–18s)
- After `max_consecutive_failures` (default 5) in a row: session aborts

---

## ONNX rotate model

Drop `rotate_model.onnx` in project root + `pip install onnxruntime`.  
Expected input: `(1, 2, 128, 128)` float32. Output: single float, angle in degrees.  
Loader is automatic — CV fallback used when not present.

---

## Debug output

`./debug/` — timestamped PNG dumps for every captcha extraction and match.  
`./solver.log` — structured log.  
`./results.json` — per-video comment outcome.

---

## File layout

```
tiktok_solver/
  tiktok_solver/
    __init__.py
    auth.py          cookie load/inject/verify
    commenter.py     search + scroll + comment loop
    config.py        all tunables
    debug.py         image dump + logging
    detect.py        captcha type detection
    drag.py          human-like drag executor
    extract.py       image extraction
    iconsolve.py     icon captcha solver
    ratelimit.py     rate-limit detection + adaptive backoff
    rotatesolve.py   rotate captcha solver + ONNX hook
    slidersolve.py   slider captcha solver
    solver.py        TikTokCaptchaSolver entry point
    stealth.py       playwright-stealth wrapper
  run.py             CLI entry point
  example.py         captcha-only demo
  requirements.txt
  README.md
  LIMITS.md
```
