"""example.py — runnable end-to-end TikTok captcha solver demo.

Usage:
    python example.py [--url https://www.tiktok.com/login] [--headless]

Requires: playwright chromium installed
    playwright install chromium
"""
from __future__ import annotations

import argparse
import asyncio
import sys

from playwright.async_api import async_playwright

from tiktok_solver import SolverConfig, TikTokCaptchaSolver
from tiktok_solver.stealth import apply_stealth


async def main(url: str, headless: bool) -> None:
    cfg = SolverConfig(
        headless=headless,
        debug_dump=True,
        max_retries=3,
    )
    solver = TikTokCaptchaSolver(cfg)

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            headless=headless,
            args=cfg.chromium_args,
        )
        context = await browser.new_context(
            viewport={"width": 1280, "height": 800},
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/124.0.0.0 Safari/537.36"
            ),
        )
        page = await context.new_page()

        # Apply stealth patches before any navigation
        await apply_stealth(page)

        print(f"[*] Navigating to {url}")
        await page.goto(url, wait_until="domcontentloaded", timeout=30_000)

        print("[*] Waiting for captcha…")
        result = await solver.solve(page, timeout=10.0)

        if result:
            print("[+] Captcha SOLVED")
        else:
            print("[-] Captcha FAILED — check ./debug/ for images and ./solver.log")
            sys.exit(1)

        await browser.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="TikTok captcha solver demo")
    parser.add_argument(
        "--url",
        default="https://www.tiktok.com/login",
        help="Target URL (default: TikTok login)",
    )
    parser.add_argument(
        "--headless",
        action="store_true",
        help="Run browser headless (reduces solve rate significantly)",
    )
    args = parser.parse_args()
    asyncio.run(main(args.url, args.headless))
