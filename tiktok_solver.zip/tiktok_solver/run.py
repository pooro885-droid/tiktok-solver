"""run.py — TikTok comment bot CLI. Python 3.9+.

Usage (GitHub Codespaces / VPS):

  # Cookies from GitHub raw URL
  python run.py \\
    --cookie-source "https://raw.githubusercontent.com/YOU/REPO/main/cookies.txt" \\
    --search "steal an egg script" \\
    --comment 'loadstring(game:HttpGet("https://raw.githubusercontent.com/pooro885-droid/stealanegg/refs/heads/main/saemain.lua"))()' \\
    --count 50

  # Cookies from local file
  python run.py \\
    --cookie-source ./my_cookies.json \\
    --search "steal an egg script" \\
    --comment "my comment here" \\
    --count 10

  # All options via env vars (useful for secrets in Codespaces)
  COOKIE_SOURCE="https://..." SEARCH_QUERY="..." COMMENT_TEXT="..." TARGET_COUNT=50 python run.py

Options:
  --cookie-source  Raw URL or local path to Netscape/JSON cookie file [env: COOKIE_SOURCE]
  --search         TikTok search query                                 [env: SEARCH_QUERY]
  --comment        Comment text to post                                [env: COMMENT_TEXT]
  --count          Number of videos to comment on (default: 50)        [env: TARGET_COUNT]
  --headless       Run browser headless (not recommended — lowers solve rate)
  --no-debug       Disable image debug dumps
  --delay-min      Min seconds between comments (default: 8)
  --delay-max      Max seconds between comments (default: 18)
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
from pathlib import Path

from playwright.async_api import async_playwright

from tiktok_solver import SolverConfig
from tiktok_solver.auth import inject_cookies, load_cookies, verify_login
from tiktok_solver.commenter import TikTokCommenter
from tiktok_solver.stealth import apply_stealth

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
log = logging.getLogger("run")


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="TikTok comment bot — cookie auth + search + comment loop"
    )
    p.add_argument(
        "--cookie-source",
        default=os.environ.get("COOKIE_SOURCE", ""),
        help="Raw URL or local path to cookie file (Netscape or JSON)",
    )
    p.add_argument(
        "--search",
        default=os.environ.get("SEARCH_QUERY", ""),
        help="TikTok search query",
    )
    p.add_argument(
        "--comment",
        default=os.environ.get("COMMENT_TEXT", ""),
        help="Comment text to post on each video",
    )
    p.add_argument(
        "--count",
        type=int,
        default=int(os.environ.get("TARGET_COUNT", "50")),
        help="Number of videos to comment on (default: 50)",
    )
    p.add_argument(
        "--headless",
        action="store_true",
        default=os.environ.get("HEADLESS", "").lower() in ("1", "true", "yes"),
        help="Run browser headless",
    )
    p.add_argument(
        "--no-debug",
        action="store_true",
        help="Disable debug image dumps",
    )
    p.add_argument(
        "--delay-min",
        type=float,
        default=float(os.environ.get("DELAY_MIN", "8.0")),
        help="Min seconds between comments (default: 8)",
    )
    p.add_argument(
        "--delay-max",
        type=float,
        default=float(os.environ.get("DELAY_MAX", "18.0")),
        help="Max seconds between comments (default: 18)",
    )
    p.add_argument(
        "--output",
        default="results.json",
        help="Path to write JSON results summary (default: results.json)",
    )
    return p.parse_args()


async def main() -> int:
    args = _parse_args()

    # Validate required args
    missing = []
    if not args.cookie_source:
        missing.append("--cookie-source (or env COOKIE_SOURCE)")
    if not args.search:
        missing.append("--search (or env SEARCH_QUERY)")
    if not args.comment:
        missing.append("--comment (or env COMMENT_TEXT)")
    if missing:
        log.error("missing required arguments:\n  " + "\n  ".join(missing))
        return 1

    cfg = SolverConfig(
        cookie_source=args.cookie_source,
        search_query=args.search,
        comment_text=args.comment,
        target_video_count=args.count,
        headless=args.headless,
        debug_dump=not args.no_debug,
        comment_delay_min=args.delay_min,
        comment_delay_max=args.delay_max,
    )

    log.info("=== TikTok Comment Bot ===")
    log.info("search:   %r", cfg.search_query)
    log.info("comment:  %r", cfg.comment_text[:80] + ("…" if len(cfg.comment_text) > 80 else ""))
    log.info("target:   %d videos", cfg.target_video_count)
    log.info("headless: %s", cfg.headless)

    # Load cookies
    log.info("loading cookies from: %s", cfg.cookie_source)
    try:
        cookies = await load_cookies(cfg.cookie_source)
    except Exception as exc:
        log.error("cookie load failed: %s", exc)
        return 1

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            headless=cfg.headless,
            args=cfg.chromium_args,
        )
        context = await browser.new_context(
            viewport=cfg.viewport,
            user_agent=cfg.user_agent,
            locale="en-US",
            timezone_id="America/New_York",
        )

        # Inject cookies before any navigation
        await inject_cookies(context, cookies)

        page = await context.new_page()
        await apply_stealth(page)

        # Verify login
        log.info("verifying login...")
        logged_in = await verify_login(page)
        if not logged_in:
            log.error(
                "login verification failed — cookies may be expired. "
                "Export fresh cookies and try again."
            )
            await browser.close()
            return 1
        log.info("login OK")

        # Run comment bot
        commenter = TikTokCommenter(page, cfg)
        results = await commenter.run()

        await browser.close()

    # Summary
    total = len(results)
    success_count = sum(r.success for r in results)
    log.info("=== Results: %d/%d succeeded ===", success_count, total)
    for r in results:
        icon = "✓" if r.success else "✗"
        log.info("  %s [%s] %s", icon, r.status.name, r.video_url)

    # Write JSON results
    out_data = {
        "summary": {
            "total": total,
            "succeeded": success_count,
            "failed": total - success_count,
            "search_query": cfg.search_query,
            "comment_text": cfg.comment_text,
        },
        "results": [
            {
                "video_url": r.video_url,
                "success": r.success,
                "status": r.status.name,
                "attempts": r.attempts,
                "timestamp": r.timestamp,
            }
            for r in results
        ],
    }
    Path(args.output).write_text(json.dumps(out_data, indent=2))
    log.info("results written to %s", args.output)

    return 0 if success_count > 0 else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
