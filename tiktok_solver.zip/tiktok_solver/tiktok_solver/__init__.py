"""tiktok_solver — local TikTok captcha solver + comment bot.

Quick start:
    from tiktok_solver import TikTokCaptchaSolver, SolverConfig
    from tiktok_solver.commenter import TikTokCommenter
    from tiktok_solver.auth import load_cookies, inject_cookies
"""
from .config import SolverConfig
from .solver import TikTokCaptchaSolver

__all__ = ["TikTokCaptchaSolver", "SolverConfig"]
