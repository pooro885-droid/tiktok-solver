"""auth.py — TikTok cookie auth. Python 3.9+.

Loads cookies from:
  - A raw HTTPS URL (GitHub raw link, Pastebin, etc.) — fetched at runtime
  - A local file path

Supports:
  - Netscape cookie format  (what most exporters produce)
  - JSON array format       ([{name, value, domain, path, ...}, ...])
  - JSON object format      ({name: value, ...} flat dict)

After loading, injects cookies into a Playwright BrowserContext so the
session is authenticated without touching the login form.

Dependencies: httpx>=0.27, playwright>=1.40
"""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import List, Optional
from urllib.parse import urlparse

import httpx
from playwright.async_api import BrowserContext

log = logging.getLogger("tiktok_solver.auth")

# Netscape cookie line pattern
# Fields: domain  flag  path  secure  expiry  name  value
_NETSCAPE_RE = re.compile(
    r"^(?P<domain>[^\t]+)\t"
    r"(?P<flag>TRUE|FALSE)\t"
    r"(?P<path>[^\t]+)\t"
    r"(?P<secure>TRUE|FALSE)\t"
    r"(?P<expiry>\d*)\t"
    r"(?P<name>[^\t]+)\t"
    r"(?P<value>.*)$"
)

PlaywrightCookie = dict  # Playwright's cookie shape


def _parse_netscape(raw: str) -> List[PlaywrightCookie]:
    """Parse a Netscape/Mozilla cookie file string into Playwright cookies."""
    cookies: List[PlaywrightCookie] = []
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = _NETSCAPE_RE.match(line)
        if not m:
            log.debug("skipping unmatched netscape line: %r", line[:80])
            continue
        domain = m.group("domain").lstrip(".")
        # Playwright wants sameSite as enum string
        cookie: PlaywrightCookie = {
            "name": m.group("name"),
            "value": m.group("value"),
            "domain": domain,
            "path": m.group("path"),
            "secure": m.group("secure") == "TRUE",
            "httpOnly": False,
            "sameSite": "None",
        }
        expiry_str = m.group("expiry")
        if expiry_str:
            cookie["expires"] = int(expiry_str)
        cookies.append(cookie)
    return cookies


def _parse_json(raw: str) -> List[PlaywrightCookie]:
    """Parse JSON cookie export into Playwright cookies."""
    data = json.loads(raw)
    cookies: List[PlaywrightCookie] = []

    if isinstance(data, dict):
        # Flat {name: value} dict — assume tiktok.com
        for name, value in data.items():
            cookies.append({
                "name": name,
                "value": str(value),
                "domain": "tiktok.com",
                "path": "/",
                "secure": True,
                "httpOnly": False,
                "sameSite": "None",
            })
        return cookies

    if isinstance(data, list):
        for item in data:
            if not isinstance(item, dict):
                continue
            name = item.get("name") or item.get("Name", "")
            value = item.get("value") or item.get("Value", "")
            domain = item.get("domain") or item.get("Domain", "tiktok.com")
            domain = domain.lstrip(".")
            cookie: PlaywrightCookie = {
                "name": name,
                "value": str(value),
                "domain": domain,
                "path": item.get("path", item.get("Path", "/")),
                "secure": bool(item.get("secure", item.get("Secure", True))),
                "httpOnly": bool(item.get("httpOnly", item.get("HttpOnly", False))),
                "sameSite": item.get("sameSite", item.get("SameSite", "None")),
            }
            if "expirationDate" in item:
                cookie["expires"] = int(item["expirationDate"])
            elif "expiry" in item:
                cookie["expires"] = int(item["expiry"])
            cookies.append(cookie)
        return cookies

    raise ValueError(f"unrecognised JSON cookie format: {type(data)}")


def _detect_and_parse(raw: str) -> List[PlaywrightCookie]:
    """Auto-detect format (Netscape vs JSON) and parse."""
    stripped = raw.strip()
    if stripped.startswith(("{", "[")):
        log.debug("detected JSON cookie format")
        return _parse_json(stripped)
    log.debug("detected Netscape cookie format")
    return _parse_netscape(stripped)


async def _fetch_remote(url: str) -> str:
    """Fetch cookie file content from a remote URL."""
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError(f"cookie URL must be http/https, got: {url!r}")
    log.info("fetching cookies from %s", url)
    async with httpx.AsyncClient(timeout=15.0, follow_redirects=True) as client:
        resp = await client.get(url, headers={
            "User-Agent": "curl/8.4.0",
            "Accept": "*/*",
        })
        resp.raise_for_status()
        return resp.text


def _load_local(path_str: str) -> str:
    p = Path(path_str)
    if not p.exists():
        raise FileNotFoundError(f"cookie file not found: {path_str!r}")
    return p.read_text(encoding="utf-8")


async def load_cookies(source: str) -> List[PlaywrightCookie]:
    """Load cookies from *source* (URL or file path).

    Returns a list of Playwright-compatible cookie dicts.
    Raises on fetch/parse failure.
    """
    if not source:
        raise ValueError("cookie source is empty — set --cookie-source or COOKIE_SOURCE")

    if source.startswith("http://") or source.startswith("https://"):
        raw = await _fetch_remote(source)
    else:
        raw = _load_local(source)

    cookies = _detect_and_parse(raw)
    log.info("loaded %d cookies from %s", len(cookies), source)
    return cookies


async def inject_cookies(context: BrowserContext, cookies: List[PlaywrightCookie]) -> None:
    """Inject *cookies* into a Playwright BrowserContext."""
    # Filter to TikTok domains only for safety
    tiktok_cookies = [
        c for c in cookies
        if "tiktok.com" in c.get("domain", "")
        or "bytedance.com" in c.get("domain", "")
    ]
    if not tiktok_cookies:
        log.warning(
            "no tiktok.com cookies found in the loaded set (%d total) — "
            "injecting all cookies anyway", len(cookies)
        )
        tiktok_cookies = cookies

    await context.add_cookies(tiktok_cookies)
    log.info("injected %d cookies into browser context", len(tiktok_cookies))


async def verify_login(page) -> bool:
    """Navigate to TikTok and check if the session cookie gives a logged-in state.

    Returns True if the account appears authenticated.
    """
    try:
        await page.goto("https://www.tiktok.com/", wait_until="domcontentloaded", timeout=20_000)
        # Logged-in indicator: profile icon, upload button, or absence of login button
        logged_in_sels = [
            "[data-e2e='profile-icon']",
            "[data-e2e='nav-upload']",
            "[class*='DivHeaderUserLoginContainer'] [class*='Avatar']",
            "button[class*='upload']",
        ]
        login_button_sels = [
            "[data-e2e='login-button']",
            "button[class*='LoginButton']",
        ]
        import asyncio
        await asyncio.sleep(2.0)  # let page settle

        for sel in logged_in_sels:
            count = await page.locator(sel).count()
            if count > 0:
                log.info("login verified via selector: %s", sel)
                return True

        for sel in login_button_sels:
            count = await page.locator(sel).count()
            if count > 0:
                log.warning("login button visible — cookies may be expired or invalid")
                return False

        # Ambiguous — assume logged in if no login button found
        log.info("login state ambiguous — proceeding (no login button detected)")
        return True

    except Exception as exc:
        log.error("login verification error: %s", exc)
        return False
