"""commenter.py — TikTok search + scroll + comment loop. Python 3.9+.

Flow:
  1. Navigate to TikTok search for query.
  2. Click first video result.
  3. Wait for video page + comment box.
  4. Type comment, submit.
  5. Detect outcome: success / rate-limit / captcha.
     - Captcha → hand off to TikTokCaptchaSolver, retry.
     - Rate-limit → AdaptiveRateLimiter.backoff(), retry.
  6. Close video, scroll feed, click next video. Repeat N times.

Dependencies: playwright>=1.40
"""
from __future__ import annotations

import asyncio
import logging
import random
import time
from dataclasses import dataclass, field
from typing import List, Optional

from playwright.async_api import Page, TimeoutError as PWTimeout

from .config import SolverConfig
from .ratelimit import AdaptiveRateLimiter, CommentStatus, detect_comment_status

log = logging.getLogger("tiktok_solver.commenter")

# ── selectors ────────────────────────────────────────────────────────────────

# Search bar
_SEARCH_INPUT_SELS = [
    "[data-e2e='search-user-input']",
    "input[class*='SearchInput']",
    "input[placeholder*='Search']",
    "#app input[type='text']",
]
_SEARCH_SUBMIT_SELS = [
    "[data-e2e='search-user-button']",
    "button[class*='SearchButton']",
    "button[type='submit']",
]

# Video items in search results / feed
_VIDEO_ITEM_SELS = [
    "[data-e2e='search-card-video-cover']",
    "[data-e2e='user-post-item']",
    "div[class*='DivItemContainer'] a",
    "a[href*='/video/']",
]

# Comment box inside video page / modal
_COMMENT_BOX_SELS = [
    "[data-e2e='comment-input']",
    "[class*='DivCommentInputContainer'] [contenteditable]",
    "[class*='comment-input'][contenteditable]",
    "div[contenteditable='true'][class*='comment']",
    "[placeholder*='Add comment']",
    "[placeholder*='comment']",
]
_COMMENT_SUBMIT_SELS = [
    "[data-e2e='comment-post']",
    "button[class*='SubmitButton']",
    "[class*='SendButton']",
    "button[type='submit'][class*='comment']",
]

# Close / back button on video modal
_CLOSE_VIDEO_SELS = [
    "[data-e2e='browse-close']",
    "[class*='DivCloseButtonWrapper']",
    "button[aria-label='Close']",
    "[class*='CloseButton']",
]

# Tab: Videos (in search results page)
_SEARCH_VIDEO_TAB_SELS = [
    "[data-e2e='search-type-videos']",
    "a[href*='/search/video']",
    "[class*='SearchTabs'] a:nth-child(1)",
]


@dataclass
class CommentResult:
    video_url: str
    comment_text: str
    success: bool
    status: CommentStatus
    timestamp: float = field(default_factory=time.time)
    attempts: int = 1


class TikTokCommenter:
    """Handles the full search → comment loop for N videos."""

    def __init__(self, page: Page, cfg: SolverConfig):
        self.page = page
        self.cfg = cfg
        self.limiter = AdaptiveRateLimiter(
            base_min=cfg.comment_delay_min,
            base_max=cfg.comment_delay_max,
            backoff_min=cfg.rate_limit_backoff_min,
            backoff_max=cfg.rate_limit_backoff_max,
        )
        self.results: List[CommentResult] = []
        self._consecutive_failures = 0

    async def run(self) -> List[CommentResult]:
        """Execute the full comment campaign. Returns list of CommentResults."""
        log.info(
            "starting comment run: query=%r comment=%r target=%d",
            self.cfg.search_query, self.cfg.comment_text, self.cfg.target_video_count,
        )

        await self._navigate_to_search()
        video_urls = await self._collect_video_urls()
        log.info("collected %d video URLs", len(video_urls))

        for idx, url in enumerate(video_urls):
            if len(self.results) >= self.cfg.target_video_count:
                break
            if self._consecutive_failures >= self.cfg.max_consecutive_failures:
                log.error(
                    "aborting: %d consecutive failures hit limit",
                    self._consecutive_failures,
                )
                break

            log.info("[%d/%d] commenting on %s", idx + 1, self.cfg.target_video_count, url)
            result = await self._comment_on_video(url)
            self.results.append(result)

            if result.success:
                self._consecutive_failures = 0
                self.limiter.record_success()
                await self.limiter.wait()
            else:
                self._consecutive_failures += 1
                if result.status == CommentStatus.RATE_LIMITED:
                    self.limiter.record_rate_limit()
                    await self.limiter.backoff()
                else:
                    await asyncio.sleep(random.uniform(3.0, 7.0))

        log.info(
            "run complete: %d/%d succeeded",
            sum(r.success for r in self.results), len(self.results),
        )
        return self.results

    # ── navigation ────────────────────────────────────────────────────────────

    async def _navigate_to_search(self) -> None:
        """Navigate to TikTok search results for the configured query."""
        import urllib.parse
        query_enc = urllib.parse.quote(self.cfg.search_query)
        search_url = f"https://www.tiktok.com/search/video?q={query_enc}"
        log.info("navigating to search: %s", search_url)
        await self.page.goto(search_url, wait_until="domcontentloaded", timeout=30_000)
        await asyncio.sleep(2.5 + random.uniform(0, 1.0))

        # Switch to Videos tab if not already there
        for sel in _SEARCH_VIDEO_TAB_SELS:
            try:
                tab = self.page.locator(sel).first
                if await tab.count() > 0:
                    await tab.click()
                    await asyncio.sleep(1.5)
                    break
            except Exception:
                pass

    async def _collect_video_urls(self) -> List[str]:
        """Scroll search results and collect up to target_video_count video URLs."""
        urls: List[str] = []
        seen: set = set()
        max_scrolls = self.cfg.target_video_count * 3  # generous scroll budget

        for _ in range(max_scrolls):
            if len(urls) >= self.cfg.target_video_count:
                break

            for sel in _VIDEO_ITEM_SELS:
                try:
                    items = self.page.locator(sel)
                    count = await items.count()
                    for i in range(count):
                        try:
                            href = await items.nth(i).get_attribute("href")
                            if href and "/video/" in href:
                                full = href if href.startswith("http") else f"https://www.tiktok.com{href}"
                                if full not in seen:
                                    seen.add(full)
                                    urls.append(full)
                        except Exception:
                            pass
                except Exception:
                    pass

            if len(urls) >= self.cfg.target_video_count:
                break

            # Scroll down
            await self.page.evaluate("window.scrollBy(0, window.innerHeight * 1.5)")
            await asyncio.sleep(random.uniform(
                self.cfg.scroll_pause_min, self.cfg.scroll_pause_max
            ))

        return urls[:self.cfg.target_video_count]

    # ── per-video comment ─────────────────────────────────────────────────────

    async def _comment_on_video(self, url: str) -> CommentResult:
        """Navigate to video, post comment, return result."""
        for attempt in range(self.cfg.comment_retry_max):
            try:
                result = await self._attempt_comment(url, attempt)
                if result.success or result.status in (
                    CommentStatus.RATE_LIMITED,
                ):
                    return result
                # On CAPTCHA: solver already handled it inside _attempt_comment
                # On ERROR: retry
                await asyncio.sleep(random.uniform(2.0, 4.0))
            except Exception as exc:
                log.error("comment attempt %d error on %s: %s", attempt + 1, url, exc)
                await asyncio.sleep(random.uniform(2.0, 5.0))

        return CommentResult(
            video_url=url,
            comment_text=self.cfg.comment_text,
            success=False,
            status=CommentStatus.ERROR,
            attempts=self.cfg.comment_retry_max,
        )

    async def _attempt_comment(self, url: str, attempt: int) -> CommentResult:
        log.debug("navigating to video: %s", url)
        await self.page.goto(url, wait_until="domcontentloaded", timeout=25_000)
        await asyncio.sleep(1.5 + random.uniform(0, 1.0))

        # Handle captcha that may appear on page load
        captcha_on_load = await self._check_and_solve_captcha()
        if not captcha_on_load and await self._captcha_present():
            log.warning("captcha present after navigation, solver returned False")

        # Find and click comment box
        box = await self._find_comment_box()
        if box is None:
            log.warning("comment box not found on %s", url)
            return CommentResult(url, self.cfg.comment_text, False, CommentStatus.ERROR, attempts=attempt + 1)

        # Click to focus
        await box.click()
        await asyncio.sleep(random.uniform(0.3, 0.7))

        # Type comment with human-like cadence
        await self._human_type(self.cfg.comment_text)
        await asyncio.sleep(random.uniform(0.4, 0.9))

        # Submit
        submitted = await self._submit_comment()
        if not submitted:
            log.warning("submit failed on %s", url)
            return CommentResult(url, self.cfg.comment_text, False, CommentStatus.ERROR, attempts=attempt + 1)

        # Wait and check outcome
        status = await detect_comment_status(self.page, self.cfg.comment_text, wait_secs=4.0)

        # Handle captcha after submit
        if status == CommentStatus.CAPTCHA:
            solved = await self._check_and_solve_captcha()
            if solved:
                # Re-submit
                await asyncio.sleep(1.0)
                status = await detect_comment_status(self.page, self.cfg.comment_text, wait_secs=4.0)

        success = status == CommentStatus.SUCCESS
        return CommentResult(
            video_url=url,
            comment_text=self.cfg.comment_text,
            success=success,
            status=status,
            attempts=attempt + 1,
        )

    # ── helpers ───────────────────────────────────────────────────────────────

    async def _find_comment_box(self):
        for sel in _COMMENT_BOX_SELS:
            try:
                loc = self.page.locator(sel).first
                if await loc.count() > 0:
                    await loc.wait_for(state="visible", timeout=5_000)
                    return loc
            except Exception:
                pass
        return None

    async def _submit_comment(self) -> bool:
        # Try submit button first
        for sel in _COMMENT_SUBMIT_SELS:
            try:
                btn = self.page.locator(sel).first
                if await btn.count() > 0 and await btn.is_enabled():
                    await btn.click()
                    return True
            except Exception:
                pass
        # Fallback: press Enter
        try:
            await self.page.keyboard.press("Enter")
            return True
        except Exception:
            pass
        return False

    async def _human_type(self, text: str) -> None:
        """Type text with randomised per-character delays."""
        for char in text:
            await self.page.keyboard.type(char)
            await asyncio.sleep(random.uniform(0.04, 0.14))

    async def _captcha_present(self) -> bool:
        for sel in [
            "#captcha-verify-container",
            "[class*='captcha_verify_container']",
            "[class*='captcha']",
        ]:
            try:
                if await self.page.locator(sel).count() > 0:
                    return True
            except Exception:
                pass
        return False

    async def _check_and_solve_captcha(self) -> bool:
        """If a captcha is present, import and invoke TikTokCaptchaSolver."""
        if not await self._captcha_present():
            return True  # no captcha, all clear

        log.info("captcha detected — invoking solver")
        try:
            from .solver import TikTokCaptchaSolver
            solver = TikTokCaptchaSolver(self.cfg)
            result = await solver.solve(self.page)
            if result:
                log.info("captcha solved successfully")
            else:
                log.warning("captcha solver failed")
            return result
        except Exception as exc:
            log.error("captcha solver error: %s", exc)
            return False
