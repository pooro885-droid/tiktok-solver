"""config.py — all tunables. Python 3.9+."""
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SolverConfig:
    # ── retries & timing ────────────────────────────────────────────────────
    max_retries: int = 3
    retry_backoff_base: float = 30.0
    retry_backoff_jitter: float = 5.0

    # ── drag dynamics ───────────────────────────────────────────────────────
    drag_step_delay_min_ms: float = 2.0
    drag_step_delay_max_ms: float = 8.0
    drag_overshoot_min_px: float = 2.0
    drag_overshoot_max_px: float = 6.0
    drag_y_jitter_min_px: float = 2.0
    drag_y_jitter_max_px: float = 4.0
    drag_pause_before_release_min_ms: float = 80.0
    drag_pause_before_release_max_ms: float = 200.0
    drag_micro_adjust_px: float = 1.5

    # ── detection timeouts ──────────────────────────────────────────────────
    captcha_appear_timeout: float = 10.0
    image_render_timeout: float = 5.0

    # ── CV thresholds ───────────────────────────────────────────────────────
    slider_match_threshold: float = 0.4
    rotate_sweep_step_deg: float = 1.0
    rotate_refine_step_deg: float = 0.25
    rotate_refine_window_deg: float = 5.0
    icon_hash_max_diff: int = 10

    # ── Playwright ──────────────────────────────────────────────────────────
    headless: bool = True
    chromium_args: list = field(default_factory=lambda: [
        "--disable-blink-features=AutomationControlled",
        "--no-sandbox",
        "--disable-dev-shm-usage",
        "--disable-gpu",
        "--disable-setuid-sandbox",
        "--disable-web-security",
        "--window-size=1280,800",
    ])
    viewport: dict = field(default_factory=lambda: {"width": 1280, "height": 800})
    user_agent: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    )

    # ── debug ───────────────────────────────────────────────────────────────
    debug_dump: bool = True
    debug_dir: Path = Path("./debug")
    log_path: Path = Path("./solver.log")

    # ── speed ───────────────────────────────────────────────────────────────
    solve_timeout: float = 2.5

    # ── comment bot ─────────────────────────────────────────────────────────
    cookie_source: str = ""          # raw URL or local file path
    search_query: str = ""           # what to search on TikTok
    comment_text: str = ""           # what to post
    target_video_count: int = 50     # how many videos to comment on
    scroll_pause_min: float = 1.5    # seconds between scrolls
    scroll_pause_max: float = 3.5
    comment_delay_min: float = 8.0   # seconds between comments (anti-rate-limit)
    comment_delay_max: float = 18.0
    rate_limit_backoff_min: float = 60.0   # if rate-limited, wait this long
    rate_limit_backoff_max: float = 180.0
    comment_retry_max: int = 3       # retries per individual comment
    max_consecutive_failures: int = 5  # abort session after this many in a row

    def __post_init__(self):
        self.debug_dir.mkdir(parents=True, exist_ok=True)
