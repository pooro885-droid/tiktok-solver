"""debug.py — image dump + structured logging helpers. Python 3.9+.

Dependencies: opencv-python>=4.8, numpy>=1.24
"""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

_LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"


def get_logger(name: str, log_path: Optional[Path] = None) -> logging.Logger:
    """Return a logger that writes to stderr and optionally to *log_path*."""
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger  # already configured

    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(logging.Formatter(_LOG_FORMAT))
    logger.addHandler(ch)

    if log_path is not None:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(log_path, encoding="utf-8")
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(logging.Formatter(_LOG_FORMAT))
        logger.addHandler(fh)

    return logger


def dump_image(
    img: np.ndarray,
    label: str,
    debug_dir: Path,
    attempt: int = 0,
) -> Path:
    """Write *img* (BGR or BGRA numpy array) to debug_dir with a timestamp.

    Returns the written path.
    """
    debug_dir.mkdir(parents=True, exist_ok=True)
    ts = int(time.time() * 1000)
    fname = f"{ts}_a{attempt}_{label}.png"
    out = debug_dir / fname
    cv2.imwrite(str(out), img)
    return out


def draw_match_result(
    background: np.ndarray,
    piece: np.ndarray,
    x_offset: int,
    y_offset: int,
    score: float,
) -> np.ndarray:
    """Overlay piece position on background for visual debugging.

    Returns a new BGR image with a rectangle drawn at the match location.
    """
    vis = background.copy()
    if vis.shape[2] == 4:
        vis = cv2.cvtColor(vis, cv2.COLOR_BGRA2BGR)
    h, w = piece.shape[:2]
    cv2.rectangle(vis, (x_offset, y_offset), (x_offset + w, y_offset + h),
                  (0, 255, 0), 2)
    cv2.putText(vis, f"{score:.3f}", (x_offset, max(y_offset - 5, 10)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
    return vis


def draw_rotate_best(
    image: np.ndarray,
    angle_deg: float,
    score: float,
) -> np.ndarray:
    """Annotate rotated image debug frame with angle and correlation score."""
    vis = image.copy()
    if vis.ndim == 2:
        vis = cv2.cvtColor(vis, cv2.COLOR_GRAY2BGR)
    label = f"angle={angle_deg:.2f}deg score={score:.4f}"
    cv2.putText(vis, label, (10, 25), cv2.FONT_HERSHEY_SIMPLEX,
                0.6, (0, 200, 255), 2)
    return vis
