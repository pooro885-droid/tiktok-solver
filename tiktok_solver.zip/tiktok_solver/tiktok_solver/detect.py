"""detect.py — iframe-aware TikTok captcha type detection. Python 3.9+.

Dependencies: playwright>=1.40
"""
from __future__ import annotations

import asyncio
import logging
from enum import Enum, auto
from typing import Optional, Tuple

from playwright.async_api import Frame, Page, TimeoutError as PWTimeout

from .config import SolverConfig

log = logging.getLogger("tiktok_solver.detect")

# ── selectors ────────────────────────────────────────────────────────────────
_CONTAINER_SELECTORS = [
    "#captcha-verify-container",
    ".captcha_verify_container",
    "[class*='captcha_verify']",
    "[id*='captcha']",
    "[class*='captcha']",
]

_TYPE_HINTS = {
    "SLIDER": [
        "[class*='slider']",
        "[class*='captcha_verify_slide']",
        ".captcha-slider-btn",
        "[class*='slide-button']",
    ],
    "ROTATE": [
        "[class*='rotate']",
        "[class*='whirl']",
        "[class*='spin']",
        ".captcha_verify_img_rotate",
    ],
    "ICON": [
        "[class*='icon']",
        "[class*='select']",
        "[class*='puzzle']",
        ".captcha_verify_img_select",
    ],
}


class CaptchaType(Enum):
    SLIDER = auto()
    ROTATE = auto()
    ICON = auto()
    UNKNOWN = auto()


async def _images_rendered(frame: Frame, timeout: float) -> bool:
    """Wait until at least one captcha image has naturalWidth > 0."""
    deadline = asyncio.get_event_loop().time() + timeout
    while asyncio.get_event_loop().time() < deadline:
        rendered = await frame.evaluate("""
            () => {
                const imgs = document.querySelectorAll('img');
                return Array.from(imgs).some(i => i.naturalWidth > 0);
            }
        """)
        if rendered:
            return True
        await asyncio.sleep(0.15)
    return False


async def _probe_frame(
    frame: Frame,
    cfg: SolverConfig,
) -> Optional[Tuple[CaptchaType, Frame]]:
    """Return (CaptchaType, frame) if a captcha container is found in *frame*."""
    # Check container presence
    container_found = False
    for sel in _CONTAINER_SELECTORS:
        try:
            el = frame.locator(sel).first
            if await el.count() > 0:
                container_found = True
                break
        except Exception:
            continue

    if not container_found:
        return None

    # Wait for images to render before type-sniffing
    rendered = await _images_rendered(frame, cfg.image_render_timeout)
    if not rendered:
        log.warning("captcha container found but images haven't rendered yet")

    # Sniff captcha type from DOM hints
    for ctype_name, selectors in _TYPE_HINTS.items():
        for sel in selectors:
            try:
                count = await frame.locator(sel).count()
                if count > 0:
                    log.info("detected captcha type=%s via selector=%s", ctype_name, sel)
                    return CaptchaType[ctype_name], frame
            except Exception:
                continue

    log.info("container found but type unknown — returning UNKNOWN")
    return CaptchaType.UNKNOWN, frame


async def detect_captcha(
    page: Page,
    cfg: SolverConfig,
) -> Tuple[CaptchaType, Optional[Frame]]:
    """Detect captcha type across the main frame and all child iframes.

    Returns (CaptchaType, frame) where frame is the frame that holds the
    captcha. Returns (UNKNOWN, None) if nothing is found.
    """
    # Wait for any captcha container to appear at all
    appeared = False
    try:
        await page.wait_for_selector(
            ", ".join(_CONTAINER_SELECTORS),
            timeout=cfg.captcha_appear_timeout * 1000,
            state="attached",
        )
        appeared = True
    except PWTimeout:
        pass

    if not appeared:
        # Check iframes even if main-frame wait timed out
        log.debug("no container in main frame within timeout, probing iframes")

    # Probe main frame first
    result = await _probe_frame(page.main_frame, cfg)
    if result:
        return result

    # Walk all frames
    for frame in page.frames:
        if frame == page.main_frame:
            continue
        try:
            result = await _probe_frame(frame, cfg)
            if result:
                return result
        except Exception as exc:
            log.debug("frame probe error: %s", exc)
            continue

    log.warning("no captcha detected on page or iframes")
    return CaptchaType.UNKNOWN, None
