"""drag.py — human-like drag executor. Python 3.9+.

Ease-out cubic path, overshoot + correction, Y jitter, per-step delay,
pause-before-release, micro-adjust on release.

Dependencies: playwright>=1.40
"""
from __future__ import annotations

import asyncio
import logging
import random
from typing import Optional

from playwright.async_api import Frame, Locator, Page

from .config import SolverConfig

log = logging.getLogger("tiktok_solver.drag")


def _ease_out_cubic(t: float) -> float:
    """t in [0, 1] → eased value in [0, 1]."""
    return 1.0 - (1.0 - t) ** 3


def _build_path(
    x0: float,
    y0: float,
    x1: float,
    y1: float,
    steps: int,
    overshoot_px: float,
    y_jitter_max: float,
) -> list[tuple[float, float]]:
    """Generate mouse path from (x0,y0) → (x1,y1) with overshoot and y-jitter.

    Overshoot: path goes slightly past x1, then a correction step back.
    Y jitter: each step gets a small random y deviation.
    """
    # Main path: 0 → x1 + overshoot
    x_target = x1 + overshoot_px
    main_steps = max(2, int(steps * 0.9))
    path: list[tuple[float, float]] = []

    for i in range(main_steps):
        t = (i + 1) / main_steps
        eased = _ease_out_cubic(t)
        x = x0 + (x_target - x0) * eased
        y_jitter = random.uniform(-y_jitter_max, y_jitter_max)
        y = y0 + y_jitter
        path.append((x, y))

    # Correction: slide back from overshoot to x1
    correction_steps = max(1, steps - main_steps)
    for i in range(correction_steps):
        t = (i + 1) / correction_steps
        x = x_target + (x1 - x_target) * t
        y = y0 + random.uniform(-y_jitter_max * 0.5, y_jitter_max * 0.5)
        path.append((x, y))

    return path


async def drag_slider(
    page_or_frame: Page | Frame,
    handle_selector: str,
    x_offset_px: int,
    cfg: SolverConfig,
    track_selector: Optional[str] = None,
) -> None:
    """Drag a slider handle by *x_offset_px* pixels.

    1. Locate handle via bounding box.
    2. Hover, idle briefly.
    3. mouse.down()
    4. Walk ease-out cubic path with Y jitter and per-step delay.
    5. Pause before release + micro-adjust.
    6. mouse.up()

    Args:
        page_or_frame: Playwright Page or Frame containing the slider.
        handle_selector: CSS selector for the slider handle element.
        x_offset_px: Pixels to drag right (in screen/page pixels after
                     bbox scaling).
        cfg: SolverConfig.
        track_selector: Optional track element selector to compute pixel
                        scale from natural width. If None, 1:1 assumed.
    """
    locator: Locator = page_or_frame.locator(handle_selector).first
    box = await locator.bounding_box()
    if box is None:
        raise RuntimeError(f"handle_selector={handle_selector!r} has no bounding box")

    # Scale factor: maps image-space offset → screen pixels
    scale = 1.0
    if track_selector:
        track_loc = page_or_frame.locator(track_selector).first
        track_box = await track_loc.bounding_box()
        if track_box and track_box["width"] > 0:
            # We assume bg image fills the track element
            scale = track_box["width"] / max(track_box["width"], 1)
            # (ratio = 1.0 when track width == bg pixel width; adjust if different)

    # Start position: centre of handle
    start_x = box["x"] + box["width"] / 2
    start_y = box["y"] + box["height"] / 2
    end_x = start_x + x_offset_px * scale

    overshoot = random.uniform(cfg.drag_overshoot_min_px, cfg.drag_overshoot_max_px)
    y_jitter = cfg.drag_y_jitter_max_px
    steps = 40  # sufficient granularity for human-like curve

    path = _build_path(start_x, start_y, end_x, start_y, steps, overshoot, y_jitter)

    mouse = page_or_frame.mouse if hasattr(page_or_frame, "mouse") else page_or_frame._page.mouse

    # Hover over handle first
    await mouse.move(start_x, start_y)
    await asyncio.sleep(random.uniform(0.08, 0.18))  # idle on handle

    await mouse.down()
    await asyncio.sleep(random.uniform(0.02, 0.06))  # brief settle after press

    for px, py in path:
        await mouse.move(px, py)
        delay_ms = random.uniform(cfg.drag_step_delay_min_ms, cfg.drag_step_delay_max_ms)
        await asyncio.sleep(delay_ms / 1000.0)

    # Pause before release
    pause = random.uniform(
        cfg.drag_pause_before_release_min_ms,
        cfg.drag_pause_before_release_max_ms,
    ) / 1000.0
    await asyncio.sleep(pause)

    # Micro-adjust: tiny nudge left/right before release
    nudge = random.uniform(-cfg.drag_micro_adjust_px, cfg.drag_micro_adjust_px)
    await mouse.move(path[-1][0] + nudge, path[-1][1])
    await asyncio.sleep(0.02)

    await mouse.up()
    log.info("drag complete: start_x=%.1f end_x=%.1f offset=%dpx", start_x, end_x, x_offset_px)


async def click_coordinates(
    page_or_frame: Page | Frame,
    coords: list[tuple[int, int]],
    base_x: float = 0.0,
    base_y: float = 0.0,
    delay_between: float = 0.3,
) -> None:
    """Click a list of (x, y) coords relative to (base_x, base_y)."""
    mouse = page_or_frame.mouse if hasattr(page_or_frame, "mouse") else page_or_frame._page.mouse
    for x, y in coords:
        abs_x = base_x + x
        abs_y = base_y + y
        await mouse.click(abs_x, abs_y)
        log.debug("clicked (%.0f, %.0f)", abs_x, abs_y)
        await asyncio.sleep(delay_between + random.uniform(-0.05, 0.1))
