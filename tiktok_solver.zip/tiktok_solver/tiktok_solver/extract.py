"""extract.py — image extraction from TikTok captcha frames. Python 3.9+.

Handles: <img> src, canvas toDataURL, CSS background-image, blob URLs.
Returns numpy arrays (BGRA) ready for OpenCV.

Dependencies: opencv-python>=4.8, numpy>=1.24, playwright>=1.40
"""
from __future__ import annotations

import base64
import logging
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

import cv2
import numpy as np
from playwright.async_api import Frame

from .config import SolverConfig
from .debug import dump_image

log = logging.getLogger("tiktok_solver.extract")

# ── selectors for each captcha type ──────────────────────────────────────────
_SLIDER_BACKGROUND_SELS = [
    "[class*='captcha_verify_img_slide'] img",
    "[class*='bg-image'] img",
    ".captcha_verify_img--warp img",
    "[class*='captcha-bg'] img",
]
_SLIDER_PIECE_SELS = [
    "[class*='captcha_verify_img_slide'] img:last-child",
    "[class*='captcha-piece'] img",
    "[class*='slide-puzzle-piece'] img",
    ".captcha_verify_img--cut img",
]
_ROTATE_BG_SELS = [
    "[class*='captcha_verify_img_rotate'] img:first-child",
    "[class*='rotate-bg'] img",
    ".rotate-bg img",
]
_ROTATE_PIECE_SELS = [
    "[class*='captcha_verify_img_rotate'] img:last-child",
    "[class*='rotate-fg'] img",
    ".rotate-fg img",
]
_ICON_GRID_SELS = [
    "[class*='captcha_verify_img_select'] img",
    "[class*='icon-select'] img",
    ".select-grid img",
]


@dataclass
class ExtractedImages:
    background: np.ndarray           # BGRA
    piece: Optional[np.ndarray]      # BGRA or None (icon type has list)
    icons: List[np.ndarray]          # populated for ICON type
    bg_natural_size: Tuple[int, int]  # (w, h) as rendered by browser


async def _src_to_b64(frame: Frame, selector: str) -> Optional[str]:
    """Pull base64 data from an <img> element via its src."""
    try:
        data = await frame.evaluate(f"""
            async () => {{
                const el = document.querySelector('{selector}');
                if (!el) return null;
                // already base64 data-uri
                if (el.src.startsWith('data:')) return el.src.split(',')[1];
                // blob url
                if (el.src.startsWith('blob:')) {{
                    const r = await fetch(el.src);
                    const buf = await r.arrayBuffer();
                    return btoa(String.fromCharCode(...new Uint8Array(buf)));
                }}
                // normal url — fetch it
                const r = await fetch(el.src);
                const buf = await r.arrayBuffer();
                return btoa(String.fromCharCode(...new Uint8Array(buf)));
            }}
        """)
        return data
    except Exception as exc:
        log.debug("_src_to_b64 error for %s: %s", selector, exc)
        return None


async def _canvas_to_b64(frame: Frame, selector: str) -> Optional[str]:
    """Pull base64 PNG from a <canvas> via toDataURL."""
    try:
        data = await frame.evaluate(f"""
            () => {{
                const el = document.querySelector('{selector}');
                if (!el || el.tagName !== 'CANVAS') return null;
                return el.toDataURL('image/png').split(',')[1];
            }}
        """)
        return data
    except Exception as exc:
        log.debug("_canvas_to_b64 error: %s", exc)
        return None


async def _css_bg_to_b64(frame: Frame, selector: str) -> Optional[str]:
    """Extract CSS background-image URL and fetch it."""
    try:
        data = await frame.evaluate(f"""
            async () => {{
                const el = document.querySelector('{selector}');
                if (!el) return null;
                const style = window.getComputedStyle(el);
                const bg = style.backgroundImage;
                const match = bg.match(/url\\(["']?(.+?)["']?\\)/);
                if (!match) return null;
                const url = match[1];
                if (url.startsWith('data:')) return url.split(',')[1];
                const r = await fetch(url);
                const buf = await r.arrayBuffer();
                return btoa(String.fromCharCode(...new Uint8Array(buf)));
            }}
        """)
        return data
    except Exception as exc:
        log.debug("_css_bg_to_b64 error: %s", exc)
        return None


async def _natural_size(frame: Frame, selector: str) -> Tuple[int, int]:
    """Return (naturalWidth, naturalHeight) of first matched <img>."""
    try:
        size = await frame.evaluate(f"""
            () => {{
                const el = document.querySelector('{selector}');
                if (!el) return [0, 0];
                return [el.naturalWidth, el.naturalHeight];
            }}
        """)
        return tuple(size)
    except Exception:
        return (0, 0)


def _b64_to_ndarray(b64: str) -> np.ndarray:
    raw = base64.b64decode(b64)
    arr = np.frombuffer(raw, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise ValueError("cv2.imdecode returned None — bad image data")
    # Normalise to BGRA
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGRA)
    elif img.shape[2] == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2BGRA)
    return img


async def _try_selectors(frame: Frame, selectors: List[str]) -> Optional[Tuple[str, np.ndarray, Tuple[int,int]]]:
    """Try each selector, return (sel, ndarray, natural_size) for first hit."""
    for sel in selectors:
        b64 = await _src_to_b64(frame, sel)
        if b64 is None:
            b64 = await _canvas_to_b64(frame, sel)
        if b64 is None:
            b64 = await _css_bg_to_b64(frame, sel)
        if b64:
            try:
                arr = _b64_to_ndarray(b64)
                sz = await _natural_size(frame, sel)
                return sel, arr, sz
            except Exception as exc:
                log.debug("decode failed for selector %s: %s", sel, exc)
                continue
    return None


async def extract_slider(
    frame: Frame,
    cfg: SolverConfig,
    attempt: int = 0,
) -> ExtractedImages:
    """Extract background + piece images for a slider captcha."""
    bg_result = await _try_selectors(frame, _SLIDER_BACKGROUND_SELS)
    piece_result = await _try_selectors(frame, _SLIDER_PIECE_SELS)

    if bg_result is None:
        raise RuntimeError("slider background image not extractable — selectors all missed")
    _, bg, bg_sz = bg_result

    piece = None
    if piece_result:
        _, piece, _ = piece_result

    if cfg.debug_dump:
        dump_image(bg, "slider_bg", cfg.debug_dir, attempt)
        if piece is not None:
            dump_image(piece, "slider_piece", cfg.debug_dir, attempt)

    return ExtractedImages(background=bg, piece=piece, icons=[], bg_natural_size=bg_sz)


async def extract_rotate(
    frame: Frame,
    cfg: SolverConfig,
    attempt: int = 0,
) -> ExtractedImages:
    """Extract background + rotated piece for a rotate captcha."""
    bg_result = await _try_selectors(frame, _ROTATE_BG_SELS)
    piece_result = await _try_selectors(frame, _ROTATE_PIECE_SELS)

    if bg_result is None:
        raise RuntimeError("rotate background image not extractable")
    _, bg, bg_sz = bg_result

    piece = None
    if piece_result:
        _, piece, _ = piece_result

    if cfg.debug_dump:
        dump_image(bg, "rotate_bg", cfg.debug_dir, attempt)
        if piece is not None:
            dump_image(piece, "rotate_piece", cfg.debug_dir, attempt)

    return ExtractedImages(background=bg, piece=piece, icons=[], bg_natural_size=bg_sz)


async def extract_icon(
    frame: Frame,
    cfg: SolverConfig,
    attempt: int = 0,
) -> ExtractedImages:
    """Extract all icon images for an icon-select captcha."""
    icons: List[np.ndarray] = []
    for i, sel in enumerate(_ICON_GRID_SELS):
        b64 = await _src_to_b64(frame, sel)
        if b64:
            try:
                arr = _b64_to_ndarray(b64)
                icons.append(arr)
                if cfg.debug_dump:
                    dump_image(arr, f"icon_{i}", cfg.debug_dir, attempt)
            except Exception as exc:
                log.debug("icon %d decode failed: %s", i, exc)

    # Fallback: grab all imgs inside known containers
    if not icons:
        try:
            all_b64 = await frame.evaluate("""
                async () => {
                    const imgs = document.querySelectorAll(
                        "[class*='captcha'] img, [id*='captcha'] img"
                    );
                    const results = [];
                    for (const img of imgs) {
                        try {
                            const r = await fetch(img.src);
                            const buf = await r.arrayBuffer();
                            results.push(btoa(String.fromCharCode(...new Uint8Array(buf))));
                        } catch { results.push(null); }
                    }
                    return results;
                }
            """)
            for i, b64 in enumerate(all_b64 or []):
                if b64:
                    try:
                        icons.append(_b64_to_ndarray(b64))
                    except Exception:
                        pass
        except Exception as exc:
            log.debug("icon fallback extraction error: %s", exc)

    placeholder = np.zeros((64, 64, 4), dtype=np.uint8)
    bg = icons[0] if icons else placeholder
    return ExtractedImages(background=bg, piece=None, icons=icons, bg_natural_size=(0, 0))
