"""iconsolve.py — icon-select captcha solver. Python 3.9+.

Strategy: perceptual hash comparison between reference icon(s) and grid
cells. Falls back to template matching on grayscale crops.

Dependencies: opencv-python>=4.8, numpy>=1.24
"""
from __future__ import annotations

import logging
from typing import List, Tuple

import cv2
import numpy as np

from .config import SolverConfig

log = logging.getLogger("tiktok_solver.icon")


# ── perceptual hash ──────────────────────────────────────────────────────────

def _phash(img: np.ndarray, size: int = 16) -> np.ndarray:
    """Return a 64-bit perceptual hash as a bool array (size*size // 4)."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGRA2GRAY) if img.shape[2] == 4 else \
           cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    resized = cv2.resize(gray, (size, size), interpolation=cv2.INTER_AREA)
    mean = resized.mean()
    return resized > mean


def _hamming(a: np.ndarray, b: np.ndarray) -> int:
    return int(np.sum(a != b))


# ── grid cell extraction ──────────────────────────────────────────────────────

def _extract_grid_cells(
    grid_img: np.ndarray,
    rows: int,
    cols: int,
) -> List[Tuple[np.ndarray, int, int]]:
    """Slice grid_img into (rows × cols) cells.

    Returns list of (cell_img, cx, cy) where cx/cy are cell centre coords
    relative to grid_img top-left.
    """
    h, w = grid_img.shape[:2]
    cell_h = h // rows
    cell_w = w // cols
    cells = []
    for r in range(rows):
        for c in range(cols):
            y0 = r * cell_h
            x0 = c * cell_w
            cell = grid_img[y0:y0 + cell_h, x0:x0 + cell_w]
            cx = x0 + cell_w // 2
            cy = y0 + cell_h // 2
            cells.append((cell, cx, cy))
    return cells


# ── template match fallback ───────────────────────────────────────────────────

def _template_score(reference: np.ndarray, cell: np.ndarray) -> float:
    """Normalised cross-correlation between reference and cell (grayscale)."""
    def to_gray(img):
        if img.ndim == 2:
            return img
        if img.shape[2] == 4:
            return cv2.cvtColor(img, cv2.COLOR_BGRA2GRAY)
        return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    ref_g = cv2.resize(to_gray(reference), (32, 32)).astype(float)
    cel_g = cv2.resize(to_gray(cell), (32, 32)).astype(float)
    ref_g -= ref_g.mean(); cel_g -= cel_g.mean()
    dn = np.linalg.norm(ref_g) * np.linalg.norm(cel_g)
    if dn < 1e-8:
        return 0.0
    return float(np.sum(ref_g * cel_g) / dn)


# ── public API ────────────────────────────────────────────────────────────────

def solve_icon(
    icons: List[np.ndarray],
    cfg: SolverConfig,
    grid_rows: int = 4,
    grid_cols: int = 4,
) -> List[Tuple[int, int]]:
    """Return list of (x, y) click coordinates for matching icons.

    Assumes icons[0] is the reference icon(s) and icons[1] (if present)
    is the grid image. If only one image, assume it contains both reference
    strip (top) and grid (bottom) combined.

    Returns coordinates relative to the grid image top-left origin.
    """
    if not icons:
        log.warning("no icons provided to solve_icon")
        return []

    if len(icons) == 1:
        # Split: top 20% reference strip, bottom 80% grid
        combined = icons[0]
        split = max(1, combined.shape[0] // 5)
        reference = combined[:split]
        grid_img = combined[split:]
    else:
        reference = icons[0]
        grid_img = icons[1]

    ref_hash = _phash(reference)
    cells = _extract_grid_cells(grid_img, grid_rows, grid_cols)

    matches: List[Tuple[int, int]] = []
    for cell_img, cx, cy in cells:
        h_dist = _hamming(ref_hash, _phash(cell_img))
        t_score = _template_score(reference, cell_img)
        log.debug("cell (%d,%d) hamming=%d tmpl=%.3f", cx, cy, h_dist, t_score)

        if h_dist <= cfg.icon_hash_max_diff or t_score > 0.5:
            matches.append((cx, cy))

    if not matches:
        log.warning("icon solver found no matches — returning all cell centres as fallback")
        matches = [(cx, cy) for _, cx, cy in cells]

    log.info("icon solve → %d matches: %s", len(matches), matches)
    return matches
