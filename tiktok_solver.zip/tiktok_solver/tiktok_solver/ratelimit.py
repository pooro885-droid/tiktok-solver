"""ratelimit.py — TikTok comment rate-limit detection + adaptive backoff.

TikTok's comment suppression has several observable states:
  1. Hard block  — "You're commenting too fast" toast / modal
  2. Soft shadow — comment appears locally but never posts (shadow-ban)
  3. CAPTCHA gate — captcha appears after comment submit
  4. Error toast  — generic "Failed" or network error message

This module detects all four and returns appropriate wait durations.

Dependencies: playwright>=1.40
"""
from __future__ import annotations

import asyncio
import logging
import random
from enum import Enum, auto
from typing import Optional

from playwright.async_api import Frame, Page

log = logging.getLogger("tiktok_solver.ratelimit")


class CommentStatus(Enum):
    SUCCESS = auto()       # comment posted cleanly
    RATE_LIMITED = auto()  # explicit "too fast" or quota block
    CAPTCHA = auto()       # captcha appeared after submit
    SHADOW = auto()        # submitted but likely shadow-dropped
    ERROR = auto()         # generic failure
    PENDING = auto()       # still waiting for confirmation


# ── observable DOM selectors ─────────────────────────────────────────────────

_SUCCESS_SELS = [
    "[data-e2e='comment-level-1']:last-child",
    "[class*='CommentListContainer'] [class*='comment-item']:last-child",
    "[class*='DivCommentItemWrapper']:last-child",
]
_RATE_LIMIT_SELS = [
    "[class*='toast']:not([style*='display: none'])",
    "[class*='Toast']:not([style*='display: none'])",
    "[class*='modal'][class*='warn']",
    "[data-e2e='comment-warn-modal']",
]
_RATE_LIMIT_TEXTS = [
    "too fast",
    "commenting too frequently",
    "action limit",
    "please try again",
    "frequent",
    "限制",        # Chinese: restricted
    "频繁",        # Chinese: too frequent
]
_ERROR_SELS = [
    "[class*='toast'][class*='error']",
    "[class*='Toast'][class*='error']",
    "[class*='ErrorMessage']",
]
_CAPTCHA_SELS = [
    "#captcha-verify-container",
    "[class*='captcha_verify_container']",
    "[class*='captcha']",
]


async def _text_in_selectors(
    page: Page, selectors: list[str], substrings: list[str]
) -> bool:
    for sel in selectors:
        try:
            els = page.locator(sel)
            count = await els.count()
            for i in range(count):
                text = (await els.nth(i).inner_text()).lower()
                if any(sub in text for sub in substrings):
                    return True
        except Exception:
            pass
    return False


async def detect_comment_status(
    page: Page,
    comment_text: str,
    wait_secs: float = 3.0,
) -> CommentStatus:
    """Poll page DOM for up to *wait_secs* to determine comment outcome."""
    deadline = asyncio.get_event_loop().time() + wait_secs

    while asyncio.get_event_loop().time() < deadline:
        # Captcha appeared
        for sel in _CAPTCHA_SELS:
            try:
                if await page.locator(sel).count() > 0:
                    log.info("captcha detected after comment submit")
                    return CommentStatus.CAPTCHA
            except Exception:
                pass

        # Rate-limit toast/modal
        rate_hit = await _text_in_selectors(
            page, _RATE_LIMIT_SELS, _RATE_LIMIT_TEXTS
        )
        if rate_hit:
            log.warning("rate-limit signal detected")
            return CommentStatus.RATE_LIMITED

        # Generic error
        for sel in _ERROR_SELS:
            try:
                if await page.locator(sel).count() > 0:
                    log.warning("error toast detected after comment")
                    return CommentStatus.ERROR
            except Exception:
                pass

        await asyncio.sleep(0.3)

    # No negative signal in window — treat as success
    log.debug("no error signal within %.1fs — assuming SUCCESS", wait_secs)
    return CommentStatus.SUCCESS


class AdaptiveRateLimiter:
    """Tracks consecutive comment outcomes and adjusts inter-comment delay.

    Starts at base delay. On rate-limit hit: backs off hard.
    On consecutive successes: gradually creeps delay back down.
    """

    def __init__(
        self,
        base_min: float = 8.0,
        base_max: float = 18.0,
        backoff_min: float = 60.0,
        backoff_max: float = 180.0,
    ):
        self._base_min = base_min
        self._base_max = base_max
        self._backoff_min = backoff_min
        self._backoff_max = backoff_max
        self._consecutive_success = 0
        self._consecutive_fail = 0
        self._current_min = base_min
        self._current_max = base_max

    async def wait(self) -> None:
        delay = random.uniform(self._current_min, self._current_max)
        log.debug("inter-comment delay: %.1fs", delay)
        await asyncio.sleep(delay)

    def record_success(self) -> None:
        self._consecutive_success += 1
        self._consecutive_fail = 0
        # Creep delay back down after 5 clean comments
        if self._consecutive_success % 5 == 0:
            self._current_min = max(self._base_min, self._current_min * 0.9)
            self._current_max = max(self._base_max, self._current_max * 0.9)
            log.debug(
                "delay crept down to %.1f–%.1fs after %d successes",
                self._current_min, self._current_max, self._consecutive_success,
            )

    def record_rate_limit(self) -> None:
        self._consecutive_fail += 1
        self._consecutive_success = 0
        # Hard backoff: increase floor
        self._current_min = min(self._backoff_min * self._consecutive_fail, 300.0)
        self._current_max = min(self._backoff_max * self._consecutive_fail, 600.0)
        log.warning(
            "rate-limit backoff → delay now %.1f–%.1fs (fail streak=%d)",
            self._current_min, self._current_max, self._consecutive_fail,
        )

    async def backoff(self) -> None:
        """Hard backoff sleep used immediately after a rate-limit hit."""
        wait = random.uniform(self._backoff_min, self._backoff_max)
        log.warning("hard backoff: sleeping %.1fs", wait)
        await asyncio.sleep(wait)
