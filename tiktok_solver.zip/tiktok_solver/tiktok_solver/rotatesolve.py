"""rotatesolve.py — rotate captcha angle solver. Python 3.9+.

Strategy:
  1. Coarse sweep 0–360° in cfg.rotate_sweep_step_deg steps.
  2. Fine sweep ±cfg.rotate_refine_window_deg around best coarse hit,
     step cfg.rotate_refine_step_deg.
  3. Expose RotateSolver.score(angle) hook: override with an ONNX
     regression model for tighter accuracy (CV fallback scores ~±3°).

Dependencies: opencv-python>=4.8, numpy>=1.24
Optional:     onnxruntime>=1.16  (for model hook)
"""
from __future__ import annotations

import logging
from typing import Optional, Tuple

import cv2
import numpy as np

from .config import SolverConfig
from .debug import draw_rotate_best, dump_image

log = logging.getLogger("tiktok_solver.rotate")


def _to_gray(img: np.ndarray) -> np.ndarray:
    if img.ndim == 2:
        return img
    if img.shape[2] == 4:
        return cv2.cvtColor(img, cv2.COLOR_BGRA2GRAY)
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def _rotate_image(img: np.ndarray, angle_deg: float) -> np.ndarray:
    """Rotate *img* by *angle_deg* clockwise around its centre, no crop."""
    h, w = img.shape[:2]
    cx, cy = w / 2, h / 2
    M = cv2.getRotationMatrix2D((cx, cy), -angle_deg, 1.0)
    return cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_LINEAR,
                          borderMode=cv2.BORDER_REPLICATE)


def _ncc(a: np.ndarray, b: np.ndarray) -> float:
    """Normalised cross-correlation of two same-size float arrays."""
    a = a.astype(float)
    b = b.astype(float)
    a -= a.mean()
    b -= b.mean()
    denom = (np.linalg.norm(a) * np.linalg.norm(b))
    if denom < 1e-8:
        return 0.0
    return float(np.sum(a * b) / denom)


class RotateSolver:
    """Solver for rotate/whirl captchas.

    Override `score(angle)` with an ONNX model for tighter angle prediction.
    The CV fallback achieves roughly ±3° which is borderline for TikTok's
    tolerance; a trained CNN typically reaches ±1°.
    """

    def __init__(self, bg: np.ndarray, piece: np.ndarray, cfg: SolverConfig):
        self.bg_gray = _to_gray(bg)
        self.piece_gray = _to_gray(piece)
        self.cfg = cfg
        self._model: Optional[object] = None  # onnxruntime.InferenceSession slot
        self._try_load_model()

    # ── public hook — swap in ONNX model here ────────────────────────────────

    def score(self, angle_deg: float) -> float:
        """Return a quality score for *angle_deg*. Higher = better rotation.

        Default implementation: NCC between piece rotated by angle and
        background centre region.

        To plug in an ONNX model:
            solver = RotateSolver(bg, piece, cfg)
            solver._model = onnxruntime.InferenceSession("rotate_model.onnx")
            # Override score() or subclass.
        """
        if self._model is not None:
            return self._score_onnx(angle_deg)
        return self._score_cv(angle_deg)

    # ── CV fallback ───────────────────────────────────────────────────────────

    def _score_cv(self, angle_deg: float) -> float:
        rotated = _rotate_image(self.piece_gray, angle_deg)

        # Resize piece to match background if needed
        if rotated.shape != self.bg_gray.shape:
            rotated = cv2.resize(rotated, (self.bg_gray.shape[1], self.bg_gray.shape[0]))

        return _ncc(self.bg_gray, rotated)

    # ── ONNX hook (lazy import, optional) ─────────────────────────────────────

    def _try_load_model(self) -> None:
        """Silently try to load rotate_model.onnx from cwd if onnxruntime present."""
        import pathlib
        model_path = pathlib.Path("rotate_model.onnx")
        if not model_path.exists():
            return
        try:
            import onnxruntime as ort  # type: ignore
            self._model = ort.InferenceSession(str(model_path))
            log.info("loaded ONNX rotate model from %s", model_path)
        except Exception as exc:
            log.debug("ONNX model load skipped: %s", exc)

    def _score_onnx(self, angle_deg: float) -> float:
        """Run ONNX regression model.  Input: 128×128 normalised pair concat."""
        try:
            import onnxruntime as ort  # type: ignore

            def _prep(img: np.ndarray) -> np.ndarray:
                resized = cv2.resize(img, (128, 128)).astype(np.float32) / 255.0
                return resized[np.newaxis, np.newaxis]  # (1, 1, 128, 128)

            rotated = _rotate_image(self.piece_gray, angle_deg)
            inp = np.concatenate([_prep(self.bg_gray), _prep(rotated)], axis=1)  # (1,2,128,128)
            input_name = self._model.get_inputs()[0].name
            result = self._model.run(None, {input_name: inp})
            return float(result[0][0])
        except Exception as exc:
            log.debug("ONNX score error, falling back to CV: %s", exc)
            return self._score_cv(angle_deg)

    # ── sweep ─────────────────────────────────────────────────────────────────

    def _sweep(self, start: float, stop: float, step: float) -> Tuple[float, float]:
        """Return (best_angle, best_score) over [start, stop) with *step*."""
        best_angle = start
        best_score = -1.0
        angle = start
        while angle < stop:
            s = self.score(angle)
            if s > best_score:
                best_score = s
                best_angle = angle
            angle += step
        return best_angle, best_score

    def solve(self, attempt: int = 0) -> float:
        """Return the predicted rotation angle in degrees [0, 360)."""
        cfg = self.cfg

        # Coarse sweep
        coarse_angle, coarse_score = self._sweep(0.0, 360.0, cfg.rotate_sweep_step_deg)
        log.info("coarse sweep → angle=%.2f score=%.4f", coarse_angle, coarse_score)

        # Fine refine
        fine_start = max(0.0, coarse_angle - cfg.rotate_refine_window_deg)
        fine_stop = min(360.0, coarse_angle + cfg.rotate_refine_window_deg)
        fine_angle, fine_score = self._sweep(fine_start, fine_stop, cfg.rotate_refine_step_deg)
        log.info("fine sweep → angle=%.2f score=%.4f", fine_angle, fine_score)

        if self.cfg.debug_dump:
            rotated_vis = _rotate_image(
                cv2.cvtColor(self.piece_gray, cv2.COLOR_GRAY2BGR), fine_angle
            )
            vis = draw_rotate_best(rotated_vis, fine_angle, fine_score)
            dump_image(vis, "rotate_best", self.cfg.debug_dir, attempt)

        return fine_angle


def angle_to_slider_x(angle_deg: float, track_width_px: int) -> int:
    """Map rotation angle [0°, 360°) to slider x-pixel on a linear track."""
    fraction = angle_deg / 360.0
    x = int(fraction * track_width_px)
    return max(0, min(x, track_width_px))
