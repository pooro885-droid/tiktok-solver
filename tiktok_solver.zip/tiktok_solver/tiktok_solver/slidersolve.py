"""slidersolve.py — slider puzzle CV solver. Python 3.9+.

Primary:  Canny edge detect + cv2.matchTemplate (TM_CCOEFF_NORMED) with
          alpha mask from piece channel 4.
Fallback: column-sum diff on grayscale background to locate gap edge.

Dependencies: opencv-python>=4.8, numpy>=1.24
"""
from __future__ import annotations

import logging
from typing import Optional, Tuple

import cv2
import numpy as np

from .config import SolverConfig
from .debug import draw_match_result, dump_image

log = logging.getLogger("tiktok_solver.slider")


def _alpha_mask(piece: np.ndarray) -> Optional[np.ndarray]:
    """Return uint8 alpha mask from BGRA piece, or None if no alpha channel."""
    if piece.ndim == 3 and piece.shape[2] == 4:
        return piece[:, :, 3]
    return None


def _to_gray(img: np.ndarray) -> np.ndarray:
    if img.ndim == 2:
        return img
    if img.shape[2] == 4:
        return cv2.cvtColor(img, cv2.COLOR_BGRA2GRAY)
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def _canny_edges(img: np.ndarray, low: int = 50, high: int = 150) -> np.ndarray:
    gray = _to_gray(img)
    blurred = cv2.GaussianBlur(gray, (3, 3), 0)
    return cv2.Canny(blurred, low, high)


def _template_match(
    bg: np.ndarray,
    piece: np.ndarray,
    threshold: float,
    cfg: SolverConfig,
) -> Optional[Tuple[int, int, float]]:
    """Return (x, y, score) of best template match or None if below threshold."""
    bg_edges = _canny_edges(bg)
    piece_edges = _canny_edges(piece)

    mask = _alpha_mask(piece)
    if mask is not None:
        # Erode mask slightly to avoid edge bleed
        kernel = np.ones((3, 3), np.uint8)
        mask = cv2.erode(mask, kernel, iterations=1)
        # Mask must be same size as template
        piece_mask = cv2.resize(mask, (piece_edges.shape[1], piece_edges.shape[0]))
    else:
        piece_mask = None

    try:
        if piece_mask is not None:
            result = cv2.matchTemplate(
                bg_edges, piece_edges, cv2.TM_CCOEFF_NORMED, mask=piece_mask
            )
        else:
            result = cv2.matchTemplate(bg_edges, piece_edges, cv2.TM_CCOEFF_NORMED)
    except cv2.error as exc:
        log.debug("matchTemplate error: %s", exc)
        return None

    _, max_val, _, max_loc = cv2.minMaxLoc(result)
    log.debug("template match score=%.4f at loc=%s", max_val, max_loc)

    if max_val < threshold:
        log.debug("match score %.4f below threshold %.4f", max_val, threshold)
        return None

    return max_loc[0], max_loc[1], max_val


def _column_sum_fallback(bg: np.ndarray, piece_width: int) -> int:
    """Locate gap edge in background using column-sum difference.

    The puzzle gap is usually darker / lower-edge-density than surroundings.
    Returns the x-offset of the gap left edge.
    """
    gray = _to_gray(bg)
    edges = _canny_edges(gray)

    # Column sum of edge pixels across the vertical band
    col_sums = edges.sum(axis=0).astype(float)
    # Smooth
    kernel_size = max(3, piece_width // 8)
    col_sums_sm = np.convolve(col_sums, np.ones(kernel_size) / kernel_size, mode="same")

    # Skip left margin (slider handle lives there)
    margin = piece_width
    search = col_sums_sm[margin:]
    if len(search) == 0:
        return margin

    # Gap = minimum density region
    min_idx = int(np.argmin(search))
    x_offset = min_idx + margin
    log.debug("column-sum fallback → x_offset=%d", x_offset)
    return x_offset


def solve_slider(
    bg: np.ndarray,
    piece: np.ndarray,
    cfg: SolverConfig,
    attempt: int = 0,
) -> int:
    """Return x-offset (in background-image pixels) for the slider drag.

    1. Try Canny + matchTemplate with alpha mask.
    2. Fall back to column-sum gap detection.
    Result is clamped to [piece_w, bg_w - piece_w].
    """
    piece_h, piece_w = piece.shape[:2]
    bg_w = bg.shape[1]

    match = _template_match(bg, piece, cfg.slider_match_threshold, cfg)

    if match is not None:
        x, y, score = match
        if cfg.debug_dump:
            vis = draw_match_result(bg, piece, x, y, score)
            dump_image(vis, "slider_match_result", cfg.debug_dir, attempt)
        log.info("slider solved via template match: x=%d score=%.4f", x, score)
    else:
        log.info("template match below threshold — using column-sum fallback")
        x = _column_sum_fallback(bg, piece_w)

    # Clamp to valid drag range
    x_clamped = max(piece_w, min(x, bg_w - piece_w))
    log.info("slider x_offset=%d (clamped from %d)", x_clamped, x)
    return x_clamped
