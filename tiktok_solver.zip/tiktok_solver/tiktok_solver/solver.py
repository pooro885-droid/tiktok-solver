"""solver.py — TikTokCaptchaSolver entry point. Python 3.9+.

Public API:
    solver = TikTokCaptchaSolver(config)
    success = await solver.solve(page, timeout=10.0)

Dependencies: playwright>=1.40, opencv-python>=4.8, numpy>=1.24
"""
from __future__ import annotations

import asyncio
import logging
import random
from pathlib import Path
from typing import Optional

from playwright.async_api import Frame, Page, TimeoutError as PWTimeout

from .config import SolverConfig
from .debug import get_logger
from .detect import CaptchaType, detect_captcha
from .drag import click_coordinates, drag_slider
from .extract import extract_icon, extract_rotate, extract_slider
from .iconsolve import solve_icon
from .rotatesolve import RotateSolver, angle_to_slider_x
from .slidersolve import solve_slider
from .stealth import apply_stealth


# ── selectors ────────────────────────────────────────────────────────────────
_SLIDER_HANDLE_SEL = (
    "[class*='captcha-slider-btn'], "
    "[class*='slide-button'], "
    "[class*='captcha_verify_slide_button'], "
    ".secsdk-captcha-drag-icon"
)
_SLIDER_TRACK_SEL = (
    "[class*='captcha_verify_img_slide'], "
    "[class*='slide-bar'], "
    "[class*='captcha-slider-track']"
)
_ROTATE_HANDLE_SEL = (
    "[class*='captcha_verify_slide_button'], "
    "[class*='rotate-slider'], "
    ".secsdk-captcha-drag-icon"
)
_SUCCESS_SELECTORS = [
    "[class*='captcha_verify_success']",
    "[class*='verify-success']",
    ".captcha-success",
]
_LOCKOUT_SELECTORS = [
    "[class*='captcha_verify_lockout']",
    "[class*='too-many-attempts']",
    "[class*='verify-lockout']",
]


class TikTokCaptchaSolver:
    """Async solver for TikTok slider, rotate, and icon captchas."""

    def __init__(self, config: Optional[SolverConfig] = None):
        self.cfg = config or SolverConfig()
        self.log = get_logger("tiktok_solver", self.cfg.log_path)

    async def solve(self, page: Page, timeout: float = 10.0) -> bool:
        """Detect and solve the TikTok captcha on *page*.

        Retries up to cfg.max_retries times. Applies playwright-stealth if
        not already applied. Returns True on success, False on failure.
        """
        self.log.info("solver.solve() called, max_retries=%d", self.cfg.max_retries)

        for attempt in range(self.cfg.max_retries):
            self.log.info("attempt %d/%d", attempt + 1, self.cfg.max_retries)

            # Detect
            ctype, frame = await detect_captcha(page, self.cfg)
            if ctype == CaptchaType.UNKNOWN or frame is None:
                self.log.warning("no captcha detected on attempt %d", attempt + 1)
                await asyncio.sleep(1.0)
                continue

            self.log.info("captcha type=%s frame=%s", ctype.name, frame.url)

            # Dispatch to type solver
            try:
                success = await self._dispatch(page, frame, ctype, attempt)
            except Exception as exc:
                self.log.error("solve error on attempt %d: %s", attempt + 1, exc, exc_info=True)
                success = False

            if success:
                self.log.info("captcha solved on attempt %d", attempt + 1)
                return True

            # Check for lockout
            locked = await self._check_lockout(page, frame)
            if locked:
                backoff = self._lockout_backoff(attempt)
                self.log.warning("lockout detected, backing off %.1fs", backoff)
                await asyncio.sleep(backoff)
            else:
                await asyncio.sleep(1.0 + random.uniform(0.0, 0.5))

        self.log.error("all %d attempts failed", self.cfg.max_retries)
        return False

    # ── dispatch ──────────────────────────────────────────────────────────────

    async def _dispatch(
        self,
        page: Page,
        frame: Frame,
        ctype: CaptchaType,
        attempt: int,
    ) -> bool:
        if ctype == CaptchaType.SLIDER:
            return await self._solve_slider(page, frame, attempt)
        if ctype == CaptchaType.ROTATE:
            return await self._solve_rotate(page, frame, attempt)
        if ctype == CaptchaType.ICON:
            return await self._solve_icon(page, frame, attempt)
        self.log.warning("UNKNOWN captcha type — cannot solve")
        return False

    # ── slider ────────────────────────────────────────────────────────────────

    async def _solve_slider(self, page: Page, frame: Frame, attempt: int) -> bool:
        images = await extract_slider(frame, self.cfg, attempt)
        if images.piece is None:
            self.log.error("slider piece extraction failed")
            return False

        x_offset = solve_slider(images.background, images.piece, self.cfg, attempt)
        self.log.info("slider x_offset=%d", x_offset)

        await drag_slider(
            frame, _SLIDER_HANDLE_SEL, x_offset, self.cfg,
            track_selector=_SLIDER_TRACK_SEL,
        )
        return await self._wait_for_result(page, frame)

    # ── rotate ────────────────────────────────────────────────────────────────

    async def _solve_rotate(self, page: Page, frame: Frame, attempt: int) -> bool:
        images = await extract_rotate(frame, self.cfg, attempt)
        if images.piece is None:
            self.log.error("rotate piece extraction failed")
            return False

        solver = RotateSolver(images.background, images.piece, self.cfg)
        angle = solver.solve(attempt)
        self.log.info("rotate angle=%.2f°", angle)

        # Determine track width from handle element bounding box
        track_width = await self._get_track_width(frame, _ROTATE_HANDLE_SEL)
        x_offset = angle_to_slider_x(angle, track_width)
        self.log.info("rotate → slider x_offset=%d (track_width=%d)", x_offset, track_width)

        await drag_slider(frame, _ROTATE_HANDLE_SEL, x_offset, self.cfg)
        return await self._wait_for_result(page, frame)

    # ── icon ──────────────────────────────────────────────────────────────────

    async def _solve_icon(self, page: Page, frame: Frame, attempt: int) -> bool:
        images = await extract_icon(frame, self.cfg, attempt)
        coords = solve_icon(images.icons, self.cfg)
        if not coords:
            self.log.error("icon solver returned no coordinates")
            return False

        # Get grid element origin
        try:
            grid_sel = "[class*='captcha_verify_img_select'], [class*='icon-select']"
            grid_loc = frame.locator(grid_sel).first
            grid_box = await grid_loc.bounding_box()
            base_x = grid_box["x"] if grid_box else 0.0
            base_y = grid_box["y"] if grid_box else 0.0
        except Exception:
            base_x, base_y = 0.0, 0.0

        await click_coordinates(frame, coords, base_x, base_y)

        # Submit button
        try:
            submit_sel = "[class*='captcha_verify_btn'], [class*='verify-btn'], button[type='submit']"
            btn = frame.locator(submit_sel).first
            if await btn.count() > 0:
                await btn.click()
        except Exception as exc:
            self.log.debug("submit click failed: %s", exc)

        return await self._wait_for_result(page, frame)

    # ── helpers ───────────────────────────────────────────────────────────────

    async def _wait_for_result(self, page: Page, frame: Frame) -> bool:
        """Wait up to 4s for success or failure after drag/click."""
        deadline = asyncio.get_event_loop().time() + 4.0

        while asyncio.get_event_loop().time() < deadline:
            # Check success
            for sel in _SUCCESS_SELECTORS:
                try:
                    if await frame.locator(sel).count() > 0:
                        return True
                    if await page.locator(sel).count() > 0:
                        return True
                except Exception:
                    pass

            # Check container gone (also indicates success on some variants)
            container_gone = True
            for sel in ["#captcha-verify-container", "[class*='captcha_verify_container']"]:
                try:
                    if await page.locator(sel).count() > 0 or await frame.locator(sel).count() > 0:
                        container_gone = False
                        break
                except Exception:
                    pass
            if container_gone:
                return True

            await asyncio.sleep(0.2)

        return False

    async def _check_lockout(self, page: Page, frame: Frame) -> bool:
        for sel in _LOCKOUT_SELECTORS:
            try:
                if await frame.locator(sel).count() > 0:
                    return True
                if await page.locator(sel).count() > 0:
                    return True
            except Exception:
                pass
        return False

    def _lockout_backoff(self, attempt: int) -> float:
        base = self.cfg.retry_backoff_base * (2 ** attempt)
        jitter = random.uniform(-self.cfg.retry_backoff_jitter, self.cfg.retry_backoff_jitter)
        return max(1.0, base + jitter)

    async def _get_track_width(self, frame: Frame, handle_sel: str) -> int:
        """Return track width in pixels from CSS or fallback to 280."""
        try:
            track_sel = _SLIDER_TRACK_SEL
            box = await frame.locator(track_sel).first.bounding_box()
            if box and box["width"] > 0:
                return int(box["width"])
        except Exception:
            pass
        return 280  # TikTok default track ~280px
