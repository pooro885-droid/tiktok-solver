"""stealth.py — playwright-stealth config wrapper. Python 3.9+.

Dependency: playwright-stealth>=1.0.6  (pip install playwright-stealth)
"""
from playwright.async_api import Page

try:
    from playwright_stealth import stealth_async, StealthConfig
    _STEALTH_AVAILABLE = True
except ImportError:
    _STEALTH_AVAILABLE = False


async def apply_stealth(page: Page) -> None:
    """Apply stealth patches to *page* before any navigation.

    If playwright-stealth is not installed the function logs a warning and
    returns — the solver will still run but detection rates will rise.
    """
    if not _STEALTH_AVAILABLE:
        import logging
        logging.getLogger("tiktok_solver.stealth").warning(
            "playwright-stealth not installed; captcha verification may fail "
            "even on correct solves. Run: pip install playwright-stealth"
        )
        return

    cfg = StealthConfig(
        navigator_languages=False,   # keep Accept-Language from browser default
        navigator_vendor=False,      # keep vendor string from browser default
        navigator_user_agent=False,  # keep UA from browser default
    )
    await stealth_async(page, cfg)


async def configure_context_stealth(context) -> None:
    """Register stealth on every new page that opens in *context*."""
    context.on("page", lambda p: p.add_init_script(_STEALTH_INIT_SCRIPT))


# Minimal fallback init-script for environments without playwright-stealth.
# Hides the most fingerprinted navigator flags that TikTok probes first.
_STEALTH_INIT_SCRIPT = """
(() => {
    // Remove webdriver flag
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });

    // Spoof plugins length
    Object.defineProperty(navigator, 'plugins', {
        get: () => ({ length: 3, item: () => null }),
    });

    // Spoof languages
    Object.defineProperty(navigator, 'languages', {
        get: () => ['en-US', 'en'],
    });

    // Chrome runtime stub
    if (!window.chrome) {
        window.chrome = { runtime: {} };
    }

    // Permissions stub (prevents Notification permission leak)
    const origQuery = window.navigator.permissions.query.bind(
        window.navigator.permissions
    );
    window.navigator.permissions.query = (params) =>
        params.name === 'notifications'
            ? Promise.resolve({ state: Notification.permission })
            : origQuery(params);
})();
"""
